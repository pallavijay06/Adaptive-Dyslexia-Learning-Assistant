"""Dyslexia-friendly reading experience components for Streamlit."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from textwrap import dedent

import streamlit as st

from components.reading.content_formatter import (
    ReadingContentBlock,
    format_content_for_reading,
)
from components.reading.vocabulary_popup import (
    BUILT_IN_DICTIONARY,
    _get_definition,
    extract_difficult_words,
)
from components.session_state import (
    get_ui_preferences,
    initialize_learning_mode,
)
from components.ui_constants import (
    CHARACTER_SPACING,
    FONTS,
    FONT_SIZES,
    LEARNING_MODES,
    READING_CARD_BORDER_WIDTH,
    READING_COMPACT_GAP,
    READING_CONTAINER_PADDING,
    READING_CONTAINER_RADIUS,
    READING_CONTENT_MAX_WIDTH,
    READING_HEADING_LINE_HEIGHT,
    READING_HIGHLIGHT_PADDING,
    READING_HIGHLIGHT_RADIUS,
    READING_LINE_HEIGHT,
    READING_LIST_INDENT,
    READING_SECTION_GAP,
    READING_HEADING_SCALE,
    READING_SECONDARY_HEADING_SCALE,
    READING_TAKEAWAY_LIMIT,
    THEMES,
)

_SENTENCE_PATTERN = re.compile(r"[^.!?]+[.!?]?")
_WORD_PATTERN = re.compile(r"\b[A-Za-z][A-Za-z'-]*\b")
_TOKEN_PATTERN = re.compile(r"\b[A-Za-z][A-Za-z'-]*\b|[^\w\s]+|\s+")
_READING_ROW_CHARACTER_LIMIT = 64
_VOCABULARY_LINK_EXTRA_WIDTH = 2


@dataclass
class _ReadingSection:
    """A group of content blocks rendered as one reading card."""

    heading: str | None = None
    blocks: list[ReadingContentBlock] = field(default_factory=list)


@dataclass(frozen=True)
class _ReadingStyle:
    """Resolved CSS values for the current accessibility preferences."""

    background_color: str
    text_color: str
    secondary_background: str
    border_color: str
    font_family: str
    font_size: int
    character_spacing: str


def render_learning_mode_switcher() -> str:
    """Render the learning mode selector and persist the chosen mode."""

    initialize_learning_mode()
    selected_mode = st.radio(
        "Learning Mode",
        options=LEARNING_MODES,
        horizontal=True,
        key="learning_mode",
    )

    return selected_mode


def render_read_mode(content: str) -> None:
    """Render dyslexia-friendly read mode for educational content.

    Args:
        content: Plain text content to display in read mode.
    """

    style = _get_reading_style()
    blocks = format_content_for_reading(content)
    difficult_words = extract_difficult_words(content)
    st.session_state.reading_difficult_words = difficult_words

    sections = _group_blocks_into_sections(blocks)
    _render_reading_widget_styles(style)

    with st.container():
        for section_index, section in enumerate(sections):
            _render_interactive_section(section, difficult_words, section_index)


def render_key_takeaways(content: str) -> None:
    """Extract and render rule-based key takeaways below reading content.

    Args:
        content: Plain text content to summarize with simple heuristics.
    """

    takeaways = _extract_key_takeaways(content)
    if not takeaways:
        return

    style = _get_reading_style()
    items = "\n".join(
        f'<li class="takeaway-item">{html.escape(takeaway)}</li>'
        for takeaway in takeaways
    )

    html_content = dedent(
        f"""
        <div class="takeaways-card" aria-label="Key takeaways">
        <h2 class="takeaways-heading">Key Takeaways</h2>
        <ul class="takeaways-list">
        {items}
        </ul>
        </div>
        {_build_shared_card_styles(style)}
        <style>
        .takeaways-list {{
            margin: 0;
            padding-left: {READING_LIST_INDENT};
        }}

        .takeaway-item {{
            margin-bottom: {READING_COMPACT_GAP};
        }}

        .takeaway-item:last-child {{
            margin-bottom: 0;
        }}
        </style>
        """
    ).strip()
    _render_html(html_content)


def render_listen_mode_placeholder() -> None:
    """Render the placeholder card for future audio mode."""

    _render_placeholder_card("Audio Mode Coming Soon")


def render_visual_mode_placeholder() -> None:
    """Render the placeholder card for future visual learning mode."""

    _render_placeholder_card("Visual Learning Mode Coming Soon")


def render_reading_view(content: str) -> None:
    """Backward-compatible wrapper for the Phase 1.5 reading view."""

    render_read_mode(content)


def _render_interactive_section(
    section: _ReadingSection,
    difficult_words: list[str],
    section_index: int,
) -> None:
    """Render one section with Streamlit-native inline vocabulary support."""

    with st.container(border=True):
        if section.heading:
            st.markdown(
                f'<h2 class="reading-heading">{html.escape(section.heading)}</h2>',
                unsafe_allow_html=True,
            )

        for block_index, block in enumerate(section.blocks):
            if block.kind == "bullet_list":
                for item_index, item in enumerate(block.items):
                    _render_interactive_text_block(
                        item,
                        difficult_words,
                        key_prefix=f"section_{section_index}_block_{block_index}_item_{item_index}",
                        prefix="- ",
                    )
                continue

            _render_interactive_text_block(
                block.text,
                difficult_words,
                key_prefix=f"section_{section_index}_block_{block_index}",
            )


def _render_interactive_text_block(
    text: str,
    difficult_words: list[str],
    key_prefix: str,
    prefix: str = "",
) -> None:
    """Render readable text with difficult words as inline vocabulary links."""

    fragments = _build_reading_fragments(text, difficult_words, prefix)
    rows = _wrap_reading_fragments(fragments)
    active_word_key = f"{key_prefix}_active_vocabulary_word"

    for row_index, row in enumerate(rows):
        weights = [_fragment_column_weight(fragment) for fragment in row]
        columns = st.columns(weights, gap="small")

        for column, fragment_index in zip(columns, range(len(row)), strict=False):
            fragment = row[fragment_index]
            with column:
                if fragment["kind"] == "vocabulary":
                    _render_vocabulary_link(
                        fragment["text"],
                        key=f"{key_prefix}_word_{row_index}_{fragment_index}",
                        active_word_key=active_word_key,
                    )
                else:
                    _render_reading_text_fragment(fragment["text"])

    _render_active_vocabulary_definition(active_word_key)
    st.markdown('<div class="reading-block-spacer"></div>', unsafe_allow_html=True)


def _build_reading_fragments(
    text: str,
    difficult_words: list[str],
    prefix: str = "",
) -> list[dict[str, str]]:
    """Split text into normal text fragments and vocabulary word fragments."""

    difficult_word_lookup = {word.lower() for word in difficult_words}
    fragments: list[dict[str, str]] = []
    normal_text = prefix

    for match in _TOKEN_PATTERN.finditer(text):
        token = match.group(0)
        normalized_token = token.lower()

        if _WORD_PATTERN.fullmatch(token) and normalized_token in difficult_word_lookup:
            if normal_text:
                fragments.append({"kind": "text", "text": normal_text})
                normal_text = ""

            fragments.append({"kind": "vocabulary", "text": token})
            continue

        normal_text += token

    if normal_text:
        fragments.append({"kind": "text", "text": normal_text})

    return _merge_short_text_fragments(fragments)


def _merge_short_text_fragments(
    fragments: list[dict[str, str]],
) -> list[dict[str, str]]:
    """Attach punctuation and whitespace-only fragments to nearby text."""

    merged: list[dict[str, str]] = []

    for fragment in fragments:
        if (
            fragment["kind"] == "text"
            and merged
            and merged[-1]["kind"] == "text"
        ):
            merged[-1]["text"] += fragment["text"]
            continue

        merged.append(fragment)

    return merged


def _wrap_reading_fragments(
    fragments: list[dict[str, str]],
) -> list[list[dict[str, str]]]:
    """Wrap fragments into rows so vocabulary links stay close to source text."""

    rows: list[list[dict[str, str]]] = []
    current_row: list[dict[str, str]] = []
    current_width = 0

    for fragment in fragments:
        parts = _split_long_text_fragment(fragment)

        for part in parts:
            width = _fragment_column_weight(part)
            should_wrap = (
                current_row
                and current_width + width > _READING_ROW_CHARACTER_LIMIT
            )

            if should_wrap:
                rows.append(current_row)
                current_row = []
                current_width = 0

            current_row.append(part)
            current_width += width

    if current_row:
        rows.append(current_row)

    return rows


def _split_long_text_fragment(fragment: dict[str, str]) -> list[dict[str, str]]:
    """Split long plain text fragments while preserving vocabulary links."""

    if (
        fragment["kind"] == "vocabulary"
        or len(fragment["text"]) <= _READING_ROW_CHARACTER_LIMIT
    ):
        return [fragment]

    parts: list[dict[str, str]] = []
    words = fragment["text"].split(" ")
    current = ""

    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) > _READING_ROW_CHARACTER_LIMIT and current:
            parts.append({"kind": "text", "text": current})
            current = word
            continue

        current = candidate

    if current:
        parts.append({"kind": "text", "text": current})

    return parts


def _fragment_column_weight(fragment: dict[str, str]) -> int:
    """Return a stable Streamlit column weight for a reading fragment."""

    if fragment["kind"] == "vocabulary":
        return max(len(fragment["text"]) + _VOCABULARY_LINK_EXTRA_WIDTH, 6)

    return max(len(fragment["text"]), 6)


def _render_reading_text_fragment(text: str) -> None:
    """Render normal reading text using the active accessibility style."""

    st.markdown(
        f'<span class="reading-inline-text">{html.escape(text)}</span>',
        unsafe_allow_html=True,
    )


def _render_vocabulary_link(word: str, key: str, active_word_key: str) -> None:
    """Render a difficult word as a lightweight text-link button."""

    normalized_word = word.lower()
    current_word = st.session_state.get(active_word_key)

    if st.button(
        word,
        key=f"vocabulary_{key}",
        help=f"Show meaning for {word}",
    ):
        st.session_state[active_word_key] = (
            None if current_word == normalized_word else normalized_word
        )


def _render_active_vocabulary_definition(active_word_key: str) -> None:
    """Render the selected vocabulary meaning below the current paragraph."""

    active_word = st.session_state.get(active_word_key)
    if not active_word:
        return

    definition = _get_definition(str(active_word))
    st.markdown(
        dedent(
            f"""
            <div class="reading-vocabulary-definition" role="note">
                <strong>{html.escape(str(active_word).capitalize())}:</strong>
                {html.escape(definition)}
            </div>
            """
        ).strip(),
        unsafe_allow_html=True,
    )


def _render_reading_widget_styles(style: _ReadingStyle) -> None:
    """Apply accessibility styling to native Streamlit reading widgets."""

    vocabulary_color = _get_vocabulary_link_color(style)

    st.markdown(
        dedent(
            f"""
            <style>
            .reading-heading {{
                color: {style.text_color};
                font-family: {style.font_family};
                font-size: {READING_HEADING_SCALE};
                line-height: {READING_HEADING_LINE_HEIGHT};
                margin: 0 0 {READING_SECTION_GAP};
            }}

            .reading-inline-text {{
                color: {style.text_color};
                font-family: {style.font_family};
                font-size: {style.font_size}px;
                letter-spacing: {style.character_spacing};
                line-height: {READING_LINE_HEIGHT};
                white-space: pre-wrap;
            }}

            .reading-block-spacer {{
                height: {READING_COMPACT_GAP};
            }}

            div[data-testid="stButton"] > button {{
                background: transparent;
                border: 0;
                border-radius: 0;
                box-shadow: none;
                color: {vocabulary_color};
                font-family: {style.font_family};
                font-size: {style.font_size}px;
                font-weight: 700;
                letter-spacing: {style.character_spacing};
                line-height: {READING_LINE_HEIGHT};
                min-height: 0;
                padding: 0;
                text-decoration-color: {vocabulary_color};
                text-decoration-line: underline;
                text-decoration-thickness: 0.12em;
                text-underline-offset: 0.18em;
            }}

            div[data-testid="stButton"] > button:hover {{
                background: transparent;
                border: 0;
                color: {vocabulary_color};
                text-decoration-thickness: 0.18em;
            }}

            div[data-testid="stButton"] > button:focus {{
                outline: {READING_CARD_BORDER_WIDTH} solid {vocabulary_color};
                outline-offset: 0.18rem;
            }}

            .reading-vocabulary-definition {{
                background-color: {style.background_color};
                border-left: 0.22rem solid {vocabulary_color};
                color: {style.text_color};
                font-family: {style.font_family};
                font-size: {style.font_size}px;
                letter-spacing: {style.character_spacing};
                line-height: {READING_LINE_HEIGHT};
                margin: {READING_COMPACT_GAP} 0 {READING_SECTION_GAP};
                max-width: {READING_CONTENT_MAX_WIDTH};
                padding: {READING_COMPACT_GAP} 0 {READING_COMPACT_GAP} {READING_COMPACT_GAP};
            }}

            .reading-vocabulary-definition strong {{
                color: {style.text_color};
                font-family: {style.font_family};
                font-size: {style.font_size}px;
                font-weight: 700;
                letter-spacing: {style.character_spacing};
                line-height: {READING_LINE_HEIGHT};
            }}
            </style>
            """
        ).strip(),
        unsafe_allow_html=True,
    )


def _get_vocabulary_link_color(style: _ReadingStyle) -> str:
    """Return a readable accent color for inline vocabulary links."""

    if style.background_color == "#121826":
        return "#93C5FD"

    return "#1D4ED8"


def _group_blocks_into_sections(
    blocks: list[ReadingContentBlock],
) -> list[_ReadingSection]:
    """Group structured content blocks into heading-led reading sections."""

    sections: list[_ReadingSection] = []
    current_section = _ReadingSection()

    for block in blocks:
        if block.kind == "heading":
            if current_section.heading or current_section.blocks:
                sections.append(current_section)
            current_section = _ReadingSection(heading=block.text)
            continue

        current_section.blocks.append(block)

    if current_section.heading or current_section.blocks:
        sections.append(current_section)

    return sections


def _render_section(section: _ReadingSection, difficult_words: list[str]) -> str:
    """Render a structured section as one HTML card."""

    heading_html = (
        f'<h2 class="reading-heading">{html.escape(section.heading)}</h2>'
        if section.heading
        else ""
    )
    block_html = "\n".join(
        _render_block(block, difficult_words)
        for block in section.blocks
    )

    return (
        '<div class="reading-section-card">\n'
        f"{heading_html}\n"
        f"{block_html}\n"
        "</div>"
    )


def _render_block(block: ReadingContentBlock, difficult_words: list[str]) -> str:
    """Render one structured content block."""

    if block.kind == "bullet_list":
        items = "\n".join(
            f'<li>{_highlight_difficult_words(item, difficult_words)}</li>'
            for item in block.items
        )
        return f'<ul class="reading-bullet-list">{items}</ul>'

    return (
        '<p class="reading-paragraph">'
        f'{_highlight_difficult_words(block.text, difficult_words)}'
        "</p>"
    )


def _highlight_difficult_words(text: str, difficult_words: list[str]) -> str:
    """Wrap difficult words in accessible highlight markup."""

    if not difficult_words:
        return html.escape(text)

    difficult_word_lookup = {word.lower() for word in difficult_words}

    def replace_word(match: re.Match[str]) -> str:
        word = match.group(0)
        normalized_word = word.lower()
        escaped_word = html.escape(word)

        if normalized_word not in difficult_word_lookup:
            return escaped_word

        definition = BUILT_IN_DICTIONARY.get(
            normalized_word,
            "An important topic word from the reading.",
        )
        return (
            '<span class="reading-word-highlight" '
            f'title="{html.escape(definition, quote=True)}">{escaped_word}</span>'
        )

    return _WORD_PATTERN.sub(replace_word, text)


def _extract_key_takeaways(content: str) -> list[str]:
    """Return major points using deterministic sentence scoring."""

    sentences = [
        sentence.strip()
        for sentence in _SENTENCE_PATTERN.findall(content.replace("\n", " "))
        if len(sentence.strip().split()) >= 4
    ]
    scored_sentences = sorted(
        enumerate(sentences),
        key=lambda item: _score_takeaway_sentence(item[1]),
        reverse=True,
    )

    selected_indexes = sorted(
        index
        for index, sentence in scored_sentences[:READING_TAKEAWAY_LIMIT]
        if _score_takeaway_sentence(sentence) > 0
    )

    if not selected_indexes:
        selected_indexes = list(range(min(len(sentences), READING_TAKEAWAY_LIMIT)))

    return [_clean_takeaway(sentences[index]) for index in selected_indexes]


def _score_takeaway_sentence(sentence: str) -> int:
    """Score a sentence for takeaway usefulness."""

    lower_sentence = sentence.lower()
    score = 0

    for keyword in ("use", "used", "make", "need", "required", "process", "occurs"):
        if keyword in lower_sentence:
            score += 2

    if 6 <= len(sentence.split()) <= 22:
        score += 1

    for word in extract_difficult_words(sentence):
        if word in BUILT_IN_DICTIONARY:
            score += 1

    return score


def _clean_takeaway(sentence: str) -> str:
    """Normalize a takeaway sentence for display."""

    return sentence.strip().rstrip(".") + "."


def _render_placeholder_card(message: str) -> None:
    """Render a theme-aware placeholder card for inactive modes."""

    style = _get_reading_style()
    html_content = dedent(
        f"""
        <div class="mode-placeholder-card" aria-label="{html.escape(message)}">
        <p>{html.escape(message)}</p>
        </div>
        {_build_shared_card_styles(style)}
        <style>
        .mode-placeholder-card p {{
            margin: 0;
        }}
        </style>
        """
    ).strip()
    _render_html(html_content)


def _render_html(html_content: str) -> None:
    """Render raw HTML/CSS without exposing CSS rules as Markdown text."""

    if hasattr(st, "html"):
        st.html(html_content)
        return

    st.markdown(html_content, unsafe_allow_html=True)


def _get_reading_style() -> _ReadingStyle:
    """Resolve the current accessibility preferences into CSS values."""

    preferences = get_ui_preferences()
    theme = THEMES[preferences["theme"]]

    return _ReadingStyle(
        background_color=theme["background_color"],
        text_color=theme["text_color"],
        secondary_background=theme["secondary_background"],
        border_color=theme["border_color"],
        font_family=_resolve_font_family(preferences["font_family"]),
        font_size=FONT_SIZES[preferences["font_size"]],
        character_spacing=CHARACTER_SPACING[preferences["character_spacing"]],
    )


def _resolve_font_family(font_family: str) -> str:
    """Return a CSS-safe font-family declaration from configured options."""

    if font_family not in FONTS:
        font_family = FONTS[0]

    return f'"{html.escape(font_family, quote=True)}", sans-serif'


def _build_reading_styles(style: _ReadingStyle) -> str:
    """Build CSS for read mode using centralized configuration values."""

    return dedent(
        f"""
        <style>
        .reading-experience {{
            display: grid;
            gap: {READING_SECTION_GAP};
            font-family: {style.font_family};
            font-size: {style.font_size}px;
            line-height: {READING_LINE_HEIGHT};
            letter-spacing: {style.character_spacing};
            color: {style.text_color};
        }}

        .reading-section-card {{
            background-color: {style.secondary_background};
            border: {READING_CARD_BORDER_WIDTH} solid {style.border_color};
            border-radius: {READING_CONTAINER_RADIUS};
            padding: {READING_CONTAINER_PADDING};
        }}

        .reading-heading {{
            color: {style.text_color};
            font-size: {READING_HEADING_SCALE};
            line-height: {READING_HEADING_LINE_HEIGHT};
            margin: 0 0 {READING_SECTION_GAP};
        }}

        .reading-paragraph {{
            color: {style.text_color};
            max-width: {READING_CONTENT_MAX_WIDTH};
            margin: 0 0 {READING_SECTION_GAP};
        }}

        .reading-paragraph:last-child {{
            margin-bottom: 0;
        }}

        .reading-bullet-list {{
            color: {style.text_color};
            max-width: {READING_CONTENT_MAX_WIDTH};
            margin: 0 0 {READING_SECTION_GAP};
            padding-left: {READING_LIST_INDENT};
        }}

        .reading-bullet-list:last-child {{
            margin-bottom: 0;
        }}

        .reading-bullet-list li {{
            margin-bottom: {READING_COMPACT_GAP};
        }}

        .reading-word-highlight {{
            background-color: {style.background_color};
            border: {READING_CARD_BORDER_WIDTH} solid {style.border_color};
            border-radius: {READING_HIGHLIGHT_RADIUS};
            padding: {READING_HIGHLIGHT_PADDING};
            font-weight: 700;
        }}
        </style>
        """
    ).strip()


def _build_shared_card_styles(style: _ReadingStyle) -> str:
    """Build shared CSS for secondary reading-experience cards."""

    return dedent(
        f"""
        <style>
        .takeaways-card,
        .mode-placeholder-card {{
            background-color: {style.secondary_background};
            border: {READING_CARD_BORDER_WIDTH} solid {style.border_color};
            border-radius: {READING_CONTAINER_RADIUS};
            color: {style.text_color};
            font-family: {style.font_family};
            font-size: {style.font_size}px;
            letter-spacing: {style.character_spacing};
            line-height: {READING_LINE_HEIGHT};
            margin-top: {READING_SECTION_GAP};
            padding: {READING_CONTAINER_PADDING};
        }}

        .takeaways-heading {{
            color: {style.text_color};
            font-size: {READING_SECONDARY_HEADING_SCALE};
            margin: 0 0 {READING_SECTION_GAP};
        }}
        </style>
        """
    ).strip()


__all__ = [
    "render_key_takeaways",
    "render_learning_mode_switcher",
    "render_listen_mode_placeholder",
    "render_read_mode",
    "render_reading_view",
    "render_visual_mode_placeholder",
]
